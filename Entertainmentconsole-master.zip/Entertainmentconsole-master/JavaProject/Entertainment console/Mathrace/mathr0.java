package Mathrace;
//interface
public interface mathr0 {
void menu();
}
